//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  ___COPYRIGHT___
//

import UIKit

class ___FILEBASENAME___ViewController: UIViewController {
    
    let presenter = ___FILEBASENAME___Presenter(___FILEBASENAME___Service())
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        presenter.attachView(view: self)
    }
}

extension ___FILEBASENAME___ViewController: ___FILEBASENAME___View {
    func startLoading() {
    }
    
    func finishLoading() {
    }
}
