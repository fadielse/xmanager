//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  ___COPYRIGHT___
//

import UIKit

class ___VARIABLE_ModuleName___ViewController: UIViewController {
    
    let presenter = ___VARIABLE_ModuleName___Presenter(___VARIABLE_ModuleName___Service())
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        presenter.attachView(view: self)
    }
}

extension ___VARIABLE_ModuleName___ViewController: ___VARIABLE_ModuleName___View {
    func startLoading() {
    }
    
    func finishLoading() {
    }
}
