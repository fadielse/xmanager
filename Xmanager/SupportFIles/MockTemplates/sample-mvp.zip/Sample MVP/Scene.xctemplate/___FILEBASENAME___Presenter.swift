//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  ___COPYRIGHT___
//

import Foundation

protocol ___VARIABLE_ModuleName___View: NSObjectProtocol {
    func startLoading()
    func finishLoading()
}

class ___VARIABLE_ModuleName___Presenter {
    private let service: ___VARIABLE_ModuleName___Service
    weak private var view : ___VARIABLE_ModuleName___View?
    
    init(_ service: ___VARIABLE_ModuleName___Service) {
        self.service = service
    }
    
    func attachView(view: ___VARIABLE_ModuleName___View) {
        self.view = view
    }
}
