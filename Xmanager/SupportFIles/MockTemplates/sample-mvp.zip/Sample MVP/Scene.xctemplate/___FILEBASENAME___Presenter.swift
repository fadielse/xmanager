//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  ___COPYRIGHT___
//

import Foundation

protocol ___FILEBASENAME___View: NSObjectProtocol {
    func startLoading()
    func finishLoading()
}

class ___FILEBASENAME___Presenter {
    private let service: ___FILEBASENAME___Service
    weak private var view : ___FILEBASENAME___View?
    
    init(_ service: ___FILEBASENAME___Service) {
        self.service = service
    }
    
    func attachView(view: ___FILEBASENAME___View) {
        self.view = view
    }
}
